<div class="menu-links">
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="<?php echo e(count($item->children) >0 ? 'has-dropdown':''); ?>"><a href="<?php echo e(count($item->children) > 0 ? 'javascript:void(0)': $item->url); ?>" 
            onclick="<?php echo e(count($item->children) > 0 ? 'toggleDropdown(event)': 'toggleMenu()'); ?>"><?php echo e($item->title); ?></a>
        <?php if(count($item->children) >0): ?>
            <ul class="dropdown-menu active">
            <?php $__currentLoopData = $item->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($child->title); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH /home/anupshakyacom/public_html/resources/views/partials/menu-items/top-menu-items-mobile.blade.php ENDPATH**/ ?>