<nav id="desktop-nav">
    <div class="logo">
        Anup Shakya
    </div>
    <div>
        <?php echo e(menu('top-menu','partials.menu-items.top-menu-items-desktop')); ?>

    </div>
</nav>
<nav id="hamburger-nav">
    <div class="logo">
        Anup Shakya
    </div>
    <div class="hamburger-menu">
        <div class="hamburger-icon" onclick="toggleMenu('parent')">
            <span></span>
            <span></span>
            <span></span>
        </div>
        <?php echo e(menu('top-menu','partials.menu-items.top-menu-items-mobile')); ?>

        
    </div>
</nav><?php /**PATH /home/anupshakyacom/portfolio/resources/views/partials/top-menu.blade.php ENDPATH**/ ?>