<nav id="desktop-nav">
    <div class="logo">
        Anup Shakya
    </div>
    <div>
        <?php echo e(menu('top-menu','partials.menu-items.top-menu-items-desktop')); ?>

    </div>
    <button id="theme-switch">
        <i class="fa-solid fa-moon"></i>
        <i class="fa-solid fa-sun" ></i>
    </button>
</nav>
<nav id="hamburger-nav">
    <div class="logo">
        Anup Shakya
    </div>
    <div class="hamburger-menu">
        <div class="hamburger-icon" onclick="toggleMenu('parent')">
            <span></span>
            <span></span>
            <span></span>
        </div>
        <?php echo e(menu('top-menu','partials.menu-items.top-menu-items-mobile')); ?>

        
    </div>
     <button id="theme-switch-mobile">
        <i class="fa-solid fa-moon"></i>
        <i class="fa-solid fa-sun"></i>
    </button>
</nav><?php /**PATH /home/anupshakyacom/public_html/resources/views/partials/top-menu.blade.php ENDPATH**/ ?>