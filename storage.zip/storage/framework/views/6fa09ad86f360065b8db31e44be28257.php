<div class="progress-bar">
    <div class="filled">
    </div> 
 </div><?php /**PATH /home/anupshakyacom/public_html/resources/views/partials/top-progress-bar.blade.php ENDPATH**/ ?>