<div class="progress-bar">
    <div class="filled">
    </div> 
 </div><?php /**PATH /home/anupshakyacom/portfolio/resources/views/partials/top-progress-bar.blade.php ENDPATH**/ ?>