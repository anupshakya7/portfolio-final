<footer>
    <nav>
        <div class="nav-links-container">
            <?php echo e(menu('top-menu','partials.menu-items.top-menu-items-desktop')); ?>

        </div>
    </nav>
    <p>Copyright &#169; <?php echo e(now()->format('Y')); ?> Anup Shakya. All Rights Reserved.</p>
</footer><?php /**PATH /home/anupshakyacom/portfolio/resources/views/partials/footer.blade.php ENDPATH**/ ?>