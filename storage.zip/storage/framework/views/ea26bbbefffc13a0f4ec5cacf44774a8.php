<ul class="nav-links">
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><a href="<?php echo e($item->url); ?>"><?php echo e($item->title); ?></a></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul><?php /**PATH /home/anupshakyacom/portfolio/resources/views/partials/menu-items/top-menu-items-desktop.blade.php ENDPATH**/ ?>