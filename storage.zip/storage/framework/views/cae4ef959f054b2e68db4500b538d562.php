<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo e(setting('site.description')); ?>">
    <title><?php echo e(setting('site.title')); ?></title>
   
    <!-- Select 2 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" />
    <!-- Select 2 -->

    <!-- Custom Style -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/mediaqueries.css')); ?>">
    <!-- Custom Style -->
</head>
<body>
    <!-- Top Progress Bar -->
    <?php echo $__env->make('partials.top-progress-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Top Progress Bar -->

    <!-- Top Menu -->
    <?php echo $__env->make('partials.top-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Top Menu -->

    <!-- Main Content -->
    <?php echo $__env->yieldContent('content'); ?>
    <!-- Main Content -->

    <!-- Footer -->
    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Footer -->
    
    <!-- Typed Js for Typing Text -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/typed.js/2.0.10/typed.js"></script>
    <!-- Typed Js for Typing Text -->

    <!-- Select 2 -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
    <!-- Select 2 -->

    <!-- Custom Script -->
    <script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
    <!-- Custom Script -->

    <script>
        $(document).read(function(){
            $('.select2').select2();
        });
    </script>
</body>
</html><?php /**PATH /home/anupshakyacom/portfolio/resources/views/layout/web.blade.php ENDPATH**/ ?>