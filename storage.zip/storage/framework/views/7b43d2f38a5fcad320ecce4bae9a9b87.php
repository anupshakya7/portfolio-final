<?php $__env->startSection('content'); ?>
<section id="blog-breadcrumb-section">
    <div class="breadcrumb" style="background-image:url(<?php echo e(set_storage_url($single->banner)); ?>)">
        <div class="breadcrumb-inner">
            <h1 style="color: #000"><?php echo e($single->title); ?></h1>
            <div class="breadcrumb-inner-wrapper">
                <a href="<?php echo e(route('home')); ?>" style="color: #000"><span><i class="fa-solid fa-house"></i>Home</span></a>
                <span> - </span>
                <a href="<?php echo e(route('blog.index')); ?>" style="color: #000">Blogs</span></a>
                <span> - </span>
                <span><?php echo e($single->title); ?></span>
            </div>
        </div>
    </div>
</section>
<section id="blog-list-section" data-aos="fade-left" data-aos-delay="200" data-aos-duration="1000">
    <div class="blog-single-container">
        <?php echo $single->description; ?>

    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/anupshakyacom/public_html/resources/views/blog/single.blade.php ENDPATH**/ ?>