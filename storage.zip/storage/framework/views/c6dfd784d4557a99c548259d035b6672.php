<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" />
<link rel="stylesheet" href="<?php echo e(set_url('assets/admin/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(set_url('assets/admin/css/mediaquery.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_title', 'Portfolio Management'); ?>

<?php $__env->startSection('content'); ?>
    <div class="main_container">
        <header>
            <div class="tab_container">
                <ul>
                    <li class="active" id="about_tabBtn">About Me</li>
                    <li id="experience_tabBtn">Experience</li>
                    <li id="projects_tabBtn">Projects</li>
                </ul>
            </div>
        </header>
        <div class="tab_content">
            
            <section class="main_section" id="about_section">
                <h3 class="section_title_portfolio">About Me</h3>
                <div class="row">
                    <form action="<?php echo e(route('portfolio.about.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="card content_box">
                            <div class="about_me_top_section">
                                <div class="col-md-9">
                                    <div class="about_me_content_section">
                                        <div class="input_fields">
                                            <label for="about_bio">Description<span class="mandatory">*</span></label>
                                            <textarea name="description" placeholder="Please provide a brief introduction about yourself. Include your professional background, expertise, and any relevant details you'd like to share..." id="about_bio"><?php echo setting('site.about_description'); ?></textarea>
                                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="error_message"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="about_me_pic_section">
                                        <div class="about_me_pic">
                                            <span class="about_me_pic_close">
                                                <i class="fa-solid fa-xmark"></i>
                                            </span>
                                            <?php
                                                $about_pic = !empty(setting('site.about_pic')) ?  set_storage_url(setting('site.about_pic')) : set_url('assets/images/default_user.jpg');
                                            ?>
                                            <img src="<?php echo e($about_pic); ?>" alt="About Me Pic" id="about_me_image">
                                        </div>
                                        <div class="about_me_inputs">
                                            <label for="about_pic">Profile</label>
                                            <input type="file" name="about_pic" id="about_pic"/>
                                            <?php $__errorArgs = ['about_pic'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                             <span class="error_message"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
        
                            <div class="col-md-9">
    
                                <div class="about_education_heading">
                                    <h4 class="section_subtitle_portfolio">Education</h4>
                                </div>
                            
                                <div class="about_education_section">
                                    <div class="about_education_list">
                                        <?php if(count($educations)>0): ?>
                                        <?php $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="about_education_item card">
                                            <label for="degree">Degree Earned: <span class="mandatory">*</span></label>
                                            <input type="text" name="degree[]" value="<?php echo e($education->degree); ?>" id="degree" placeholder="Enter Degree">
                                            <label for="gpa">GPA: <span class="mandatory">*</span></label>
                                            <input type="text" name="gpa[]" value="<?php echo e($education->gpa); ?>" id="gpa" placeholder="Enter GPA">
                                            <button type="button" class="section_danger_btn remove_education_btn"><i class="fa-solid fa-minus"></i></button>
                    
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                        <div class="about_education_item card">
                                            <label for="degree">Degree Earned: <span class="mandatory">*</span></label>
                                            <input type="text" name="degree[]" id="degree" placeholder="Enter Degree">
                                            <label for="gpa">GPA: <span class="mandatory">*</span></label>
                                            <input type="text" name="gpa[]" id="gpa" placeholder="Enter GPA">
                                            <button type="button" class="section_danger_btn remove_education_btn"><i class="fa-solid fa-minus"></i></button>
                    
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    <?php $__errorArgs = ['degree'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="error_message"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <?php $__errorArgs = ['gpa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="error_message"><?php echo e($message); ?></span>
                                   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <button type="button" class="section_primary_btn" id="add_education_btn"><i class="fa-solid fa-plus"></i></button>
                            </div>
                            <div class="section_footer">
                                <button type="submit" class="section_primary_btn">Submit About Yourself</button>
                            </div>
                        </div>
                    </form>
                </div>
            </section>
            

            
            <section class="main_section" id="experience_section">
                <h3 class="section_title_portfolio">Experience</h3>
                <div class="row">
                    <form action="<?php echo e(route('portfolio.experience.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="card content_box">
        
                            <div class="col-md-12">
    
                                <div class="about_education_heading experience_heading">
                                    
                                </div>
                            
                                <div class="about_education_section">
                                    <div class="experience_education_list">
                                        <?php if(count($experiences)>0): ?>
                                        <?php $__currentLoopData = $experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="experience_education_item card">
                                            <label for="skills">Skills: <span class="mandatory">*</span></label>
                                            <input type="text" name="skills[]" id="skills" value="<?php echo e($experience->skills); ?>" placeholder="Enter Skills">
                                            <label for="gpa">Category: <span class="mandatory">*</span></label>
                                            <select name="category[]" class="" id="category">
                                                <option value="">Select Category</option>
                                                <?php $__currentLoopData = $experienceCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experienceCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($experienceCategory->id); ?>" <?php echo e($experience->category_id == $experienceCategory->id ? 'selected':''); ?>><?php echo e($experienceCategory->title); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <label for="gpa">Level: <span class="mandatory">*</span></label>
                                            <select name="level[]" class="" id="level">
                                                <option value="">Select Level</option>
                                                <option value="Beginner" <?php echo e($experience->level == "Beginner" ? 'selected':''); ?>>Beginner</option>
                                                <option value="Intermediate" <?php echo e($experience->level == "Intermediate" ? 'selected':''); ?>>Intermediate</option>
                                                <option value="Proficient" <?php echo e($experience->level == "Proficient" ? 'selected':''); ?>>Proficient</option>
                                                <option value="Expert" <?php echo e($experience->level == "Expert" ? 'selected':''); ?>>Expert</option>
                                            </select>
                                            <button type="button" class="section_danger_btn remove_experience_btn"><i class="fa-solid fa-minus"></i></button>
                    
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                        <div class="experience_education_item card">
                                            <label for="skills">Skills: <span class="mandatory">*</span></label>
                                            <input type="text" name="skills[]" id="skills" placeholder="Enter Skills">
                                            <label for="category">Category: <span class="mandatory">*</span></label>
                                            <select name="category[]" class="" id="category">
                                                <option value="">Select Category</option>
                                                <?php $__currentLoopData = $experienceCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experienceCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($experienceCategory->id); ?>"><?php echo e($experienceCategory->title); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <label for="level">Level: <span class="mandatory">*</span></label>
                                            <select name="level[]" class="" id="level">
                                                <option value="">Select Level</option>
                                                <option value="Beginner">Beginner</option>
                                                <option value="Intermediate">Intermediate</option>
                                                <option value="Proficient">Proficient</option>
                                                <option value="Expert">Expert</option>
                                            </select>
                                            <button type="button" class="section_danger_btn remove_experience_btn"><i class="fa-solid fa-minus"></i></button>
                    
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    <?php $__errorArgs = ['skills'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="error_message"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="error_message"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <?php $__errorArgs = ['level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="error_message"><?php echo e($message); ?></span>
                                   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <button type="button" class="section_primary_btn experience_primary_btn" id="add_experience_btn"><i class="fa-solid fa-plus"></i></button>
                            </div>
                            <div class="section_footer experience_footer">
                                <button type="submit" class="section_primary_btn">Submit Your Experience</button>
                            </div>
                        </div>
                    </form>
                </div>
            </section>
            

            
            <section class="main_section" id="projects_section">
                <h3 class="section_title_portfolio">Project</h3>
                <div class="row">
                    <form action="<?php echo e(route('portfolio.project.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="card content_box">
        
                            <div class="col-md-12">
    
                                <div class="about_education_heading experience_heading">
                                    
                                </div>
                            
                                <div class="about_education_section">
                                    <div class="project_education_list">
                                        <?php if(count($projects)>0): ?>
                                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="project_education_item card">
                                            <div class="project_me_pic_section">
                                                <div class="project_me_pic">
                                                    <span class="project_me_pic_close">
                                                        <i class="fa-solid fa-xmark"></i>
                                                    </span>
                                                    <?php
                                                        $project_pic = $project->project_pic !== null ? set_storage_url($project->project_pic) : set_url('assets/images/project-1.png');
                                                    ?>
                                                    <img src="<?php echo e($project_pic); ?>" alt="Project Pic" class="project_image">
                                                </div>
                                                <div class="about_me_inputs">
                                                    <label for="project_pic">Profile <span class="mandatory">*</span></label></label>
                                                    <input type="file" name="project_pic[]" value="<?php echo e($project->project_pic); ?>" class="project_pic"/>
                                                    <?php $__errorArgs = ['project_pic'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                     <span class="error_message"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="project_content">
                                                <input type="hidden" name="project_id[]" value="<?php echo e($project->id); ?>"/>
                                                <label for="title">Title: <span class="mandatory">*</span></label>
                                                <input type="text" name="title[]" id="title" value="<?php echo e($project->title); ?>" placeholder="Enter Project Title">
                                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="error_message"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                <label for="github">Github Link: </label>
                                                <input type="text" name="github[]" id="github" value="<?php echo e($project->github); ?>" placeholder="Enter Github Link">
                                                <?php $__errorArgs = ['github'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="error_message"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                <label for="live">Live Link: <span class="mandatory">*</span></label>
                                                <input type="text" name="live[]" id="live" value="<?php echo e($project->live); ?>" placeholder="Enter Live Link">
                                                <?php $__errorArgs = ['live'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="error_message"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                           
                                            <button type="button" class="section_danger_btn remove_project_btn"><i class="fa-solid fa-minus"></i></button>
                    
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                        <div class="project_education_item card">
                                            <div class="project_me_pic_section">
                                                <div class="project_me_pic">
                                                    <span class="project_me_pic_close">
                                                        <i class="fa-solid fa-xmark"></i>
                                                    </span>
                                                    <img src="<?php echo e(set_url('assets/images/project-1.png')); ?>" alt="Project Pic" class="project_image">
                                                </div>
                                                <div class="about_me_inputs">
                                                    <label for="project_pic">Profile <span class="mandatory">*</span></label></label>
                                                    <input type="file" name="project_pic[]" class="project_pic"/>
                                                    <?php $__errorArgs = ['project_pic'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                     <span class="error_message"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="project_content">
                                                <label for="title">Title: <span class="mandatory">*</span></label>
                                                <input type="text" name="title[]" id="title" placeholder="Enter Project Title">
                                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="error_message"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                <label for="github">Github Link: </label>
                                                <input type="text" name="github[]" id="github" placeholder="Enter Github Link">
                                                <?php $__errorArgs = ['github'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="error_message"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                <label for="live">Live Link: <span class="mandatory">*</span></label>
                                                <input type="text" name="live[]" id="live" placeholder="Enter Live Link">
                                                <?php $__errorArgs = ['live'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="error_message"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                           
                                            <button type="button" class="section_danger_btn remove_project_btn"><i class="fa-solid fa-minus"></i></button>
                    
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    <?php $__errorArgs = ['skills'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="error_message"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="error_message"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <?php $__errorArgs = ['level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="error_message"><?php echo e($message); ?></span>
                                   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <button type="button" class="section_primary_btn project_primary_btn" id="add_project_btn"><i class="fa-solid fa-plus"></i></button>
                            </div>
                            <div class="section_footer experience_footer">
                                <button type="submit" class="section_primary_btn">Submit Your Projects</button>
                            </div>
                        </div>
                    </form>
                </div>
                
            </section>
            
        </div>

       
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<script>
    $(document).ready(function(){
        //Session Exist
        <?php if(session()->has('success')): ?>
            toastr.success('<?php echo e(session('success')); ?>')
        <?php endif; ?>

        <?php if(session()->has('error')): ?>
            toastr.error('<?php echo e(session('error')); ?>')
        <?php endif; ?>

        //Tab Change
        //Add Active Class
        $('.tab_container ul li').click(function(){
            $('.tab_container ul li').removeClass('active');
            $(this).addClass('active');
        });

        // Hide Section When First Open Page
        $('#experience_section').hide();
        $('#projects_section').hide();

        $('#about_tabBtn').click(function(){
            $('#experience_section').hide();
            $('#projects_section').hide();
            $('#about_section').show();
        });
        $('#experience_tabBtn').click(function(){
            $('#about_section').hide();
            $('#projects_section').hide();
            $('#experience_section').show();
        });
        $('#projects_tabBtn').click(function(){
            $('#about_section').hide();
            $('#experience_section').hide();
            $('#projects_section').show();
        });

        //Add Image When User Select
        $('#about_pic').on('change',function(){
            var reader = new FileReader();

            reader.onload = function(e){
                $('#about_me_image').attr('src',e.target.result);
            };

            reader.readAsDataURL(this.files[0]);
        });

        //Remove Image when User Click Close Icon
        $('.about_me_pic_close').on('click',function(){
            $('#about_me_image').attr('src','<?php echo e(set_url('assets/images/default_user.jpg')); ?>');
            $('#about_pic').val('');
        })

        //Add New Field For Education
        $('#add_education_btn').click(function(){
            $('.about_education_list').append(`<div class="about_education_item card">
                                    <label for="degree">Degree Earned: <span class="mandatory">*</span></label>
                                    <input type="text" name="degree[]" id="degree" placeholder="Enter Degree">
                                    <label for="gpa">GPA: <span class="mandatory">*</span></label>
                                    <input type="text" name="gpa[]" id="gpa" placeholder="Enter GPA">
                                    <button type="button" class="section_danger_btn remove_education_btn"><i class="fa-solid fa-minus"></i></button>
                                </div>`);
        });

        //Remove Field For Education
        $(document).on('click','.remove_education_btn',function(){
            console.log($('.about_education_list .about_education_item').length);
            if($('.about_education_list .about_education_item').length > 1){
                $(this).closest('.about_education_item').remove();
            }else{
                toastr.error('Please add at least one entry to proceed.');
            }
        });

        //Add New Field For Experience
        $('#add_experience_btn').click(function(){
            $('.experience_education_list').append(`<div class="experience_education_item card">
                                            <label for="skills">Skills: <span class="mandatory">*</span></label>
                                            <input type="text" name="skills[]" id="skills" placeholder="Enter Skills">
                                            <label for="category">Category: <span class="mandatory">*</span></label>
                                            <select name="category[]" class="" id="category">
                                                <option value="">Select Category</option>
                                                <?php $__currentLoopData = $experienceCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experienceCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($experienceCategory->id); ?>"><?php echo e($experienceCategory->title); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <label for="level">Level: <span class="mandatory">*</span></label>
                                            <select name="level[]" class="" id="level">
                                                <option value="">Select Level</option>
                                                <option value="Beginner">Beginner</option>
                                                <option value="Intermediate">Intermediate</option>
                                                <option value="Proficient">Proficient</option>
                                                <option value="Expert">Expert</option>
                                            </select>
                                            <button type="button" class="section_danger_btn remove_experience_btn"><i class="fa-solid fa-minus"></i></button>
                    
                                        </div>`);
            $('.select2').select2();
        });


        //Remove Field For Education
        $(document).on('click','.remove_experience_btn',function(){
            console.log($('.experience_education_list .experience_education_item').length);
            if($('.experience_education_list .experience_education_item').length > 1){
                $(this).closest('.experience_education_item').remove();
            }else{
                toastr.error('Please add at least one entry to proceed.');
            }
        });


        //Add New Field For Projects
        $('#add_project_btn').click(function(){
            $('.project_education_list').append(`    <div class="project_education_item card">
                                            <div class="project_me_pic_section">
                                                <div class="project_me_pic">
                                                    <span class="project_me_pic_close">
                                                        <i class="fa-solid fa-xmark"></i>
                                                    </span>
                                                    <img src="<?php echo e(set_url('assets/images/project-1.png')); ?>" alt="Project Pic" class="project_image">
                                                </div>
                                                <div class="about_me_inputs">
                                                    <label for="project_pic">Profile <span class="mandatory">*</span></label></label>
                                                    <input type="file" name="project_pic[]" class="project_pic"/>
                                                    <?php $__errorArgs = ['project_pic'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                     <span class="error_message"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="project_content">
                                                <label for="title">Title: <span class="mandatory">*</span></label>
                                                <input type="text" name="title[]" id="title" placeholder="Enter Project Title">
                                                <label for="github">Github Link: </label>
                                                <input type="text" name="github[]" id="github" placeholder="Enter Github Link">
                                                <label for="live">Live Link: <span class="mandatory">*</span></label>
                                                <input type="text" name="live[]" id="live" placeholder="Enter Live Link">
                                            </div>
                                           
                                            <button type="button" class="section_danger_btn remove_project_btn"><i class="fa-solid fa-minus"></i></button>
                    
                                        </div>`);
        });


        //Remove Field For Projects
        $(document).on('click','.remove_project_btn',function(){
            if($('.project_education_list .project_education_item').length > 1){
                $(this).closest('.project_education_item').remove();
            }else{
                toastr.error('Please add at least one entry to proceed.');
            }
        });

        //Add Image to Project
        $('.project_education_list').on('change','.project_pic',function(){
            var reader = new FileReader();
            var projectItem = $(this).closest('.project_education_item');
            var imgElement = projectItem.find('.project_image');

            reader.onload = function(e){
                imgElement.attr('src',e.target.result);
            };

            reader.readAsDataURL(this.files[0]);
        });

        //Remove Image to Project
        $('.project_education_list').on('click','.project_me_pic_close',function(){
            var projectItem = $(this).closest('.project_education_item');
            var imgElement = projectItem.find('.project_image');
            var projectImageInput = projectItem.find('.project_pic');

            imgElement.attr('src','<?php echo e(set_url('assets/images/project-1.png')); ?>');
            projectImageInput.val('');
        });

    });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/anupshakyacom/public_html/resources/views/vendor/Voyager/portfolio/main.blade.php ENDPATH**/ ?>