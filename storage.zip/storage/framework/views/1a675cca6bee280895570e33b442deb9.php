<ul class="nav-links">
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class=<?php echo e(count($item->children) > 0 ? 'has-dropdown':''); ?>> <a href="<?php echo e($item->url); ?>"><?php echo e($item->title); ?></a>
        <?php if(count($item->children) > 0): ?>
        <ul class="dropdown-menu" id="<?php echo e(Str::slug($item->title)); ?>-menu">
            <?php $__currentLoopData = $item->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e($child->url); ?>"><?php echo e($child->title); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul><?php /**PATH /home/anupshakyacom/public_html/resources/views/partials/menu-items/top-menu-items-desktop.blade.php ENDPATH**/ ?>