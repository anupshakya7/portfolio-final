<?php $__env->startSection('code','404'); ?>
<?php $__env->startSection('message','Page Not Found'); ?>
<?php $__env->startSection('metamessage','Sorry, the page you’re looking for doesn’t exist.'); ?>

<?php echo $__env->make('errors.layout.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/anupshakyacom/public_html/resources/views/errors/404.blade.php ENDPATH**/ ?>