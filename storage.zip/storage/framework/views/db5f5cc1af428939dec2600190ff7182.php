<?php $__env->startSection('content'); ?>
<section id="profile">
    <div class="section__pic-container">
        <?php if(setting('site.owner_pic')): ?>
        <img src="<?php echo e(asset('storage/'.setting('site.owner_pic'))); ?>" alt="Anup Shakya Profile Pic">
        <?php endif; ?>
    </div>
    <div class="section__text">
        <p class="section__text__p1">Hello, I'm</p>
        <h1><?php echo e(setting('site.owner_name') ?? ''); ?></h1>
        <p class="section__text__p2"><span class="input"></span></p>
        <div class="btn-container">

            <?php if(setting('site.resume')): ?>
            <?php
                $resume = str_replace('\\','/',json_decode(setting('site.resume'))[0]->download_link);
            ?>
            
            <button class="btn btn-color-2" onclick="window.open('<?php echo e(asset('storage/'.$resume)); ?>')">
                Download CV
            </button>
            <?php endif; ?>
            
            <button class="btn btn-color-1" onclick="location.href ='./#contact'">
                Contact Info
            </button>
        </div>
        <div id="socials-container">
            <!-- Facebook -->
            <?php if(setting('site.facebook')): ?>
                <img src="<?php echo e(asset('/assets/images/facebook.png')); ?>" alt="facebook" class="icon" onclick="window.open('<?php echo e(setting('site.facebook')); ?>','_blank')">
            <?php endif; ?>
            <!-- Facebook -->

            <!-- Instagram -->
            <?php if(setting('site.instagram')): ?>
                <img src="<?php echo e(asset('/assets/images/instagram.png')); ?>" alt="instagram" class="icon" onclick="window.open('<?php echo e(setting('site.instagram')); ?>','_blank')">
            <?php endif; ?>
            <!-- Instagram -->
            
            <!-- LinkedIn -->
            <?php if(setting('site.linkedin')): ?>
                <img src="<?php echo e(asset('/assets/images/linkedin.png')); ?>" alt="linkedin" class="icon" onclick="window.open('<?php echo e(setting('site.linkedin')); ?>','_blank')">
            <?php endif; ?>
            <!-- LinkedIn -->

            <!-- Github -->
            <?php if(setting('site.github')): ?>
                <img src="<?php echo e(asset('/assets/images/github.png')); ?>" alt="github" class="icon" onclick="window.open('<?php echo e(setting('site.github')); ?>','_blank')">
            <?php endif; ?>
            <!-- Github -->
            
            <!-- Youtube -->
            <?php if(setting('site.youtube')): ?>
                <img src="<?php echo e(asset('/assets/images/youtube.png')); ?>" alt="youtube" class="icon" onclick="window.open('<?php echo e(setting('site.youtube')); ?>','_blank')">
            <?php endif; ?>
            <!-- Youtube -->

        </div>
    </div>
</section>
<section id="about">
    <p class="section__text__p1">Get To Know More</p>
    <h1 class="title">About Me</h1>
    <div class="section-container">
        <div class="section__pic-container">
            <?php
                if(setting('site.about_pic')){
                    $about_pic = Voyager::image(setting('site.about_pic'));
                }else{
                    $about_pic = asset('assets/images/default_user.jpg');
                }
            ?>
            <img src="<?php echo e($about_pic); ?>" alt="Profile Pic" class="about-pic">
        </div>
        <div class="about-details-container">
            <div class="about-containers">
                <div class="details-container">
                    <img src="<?php echo e(asset('/assets/images/experience.png')); ?>" alt="Experience Icon" class="icon"/>
                    <h3>Experience</h3>
                    <p>3+ years <br/> Full Stack Development</p>
                </div>
                <div class="details-container">
                    <img src="<?php echo e(asset('/assets/images/education.png')); ?>" alt="Education Icon" class="icon"/>
                    <h3>Education</h3>
                    <?php if(count($educations) > 0): ?>
                    <?php $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p><?php echo e($education->degree); ?><br/></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="text-container">
                <?php if(setting('site.about_description')): ?>
                <p><?php echo setting('site.about_description'); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <img src="<?php echo e(asset('/assets/images/arrow.png')); ?>" alt="Arrow Icon" class="icon arrow" onclick="location.href = './#experience'">
</section>
<section id="experience">
    <p class="section__text__p1">Explore My</p>
    <h1 class="title">Experience</h1>
    <div class="experience-details-container">
        <div class="about-containers">
            <?php if(count($experiences) > 0): ?>
            <?php $__currentLoopData = $experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="details-container">
                <h2 class="experience-sub-title"><?php echo e($experience->title); ?></h2>
                <div class="article-container">
                    <?php $__currentLoopData = $experience->skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article>
                        <img src="<?php echo e(asset('/assets/images/checkmark.png')); ?>" alt="<?php echo e($skill->skills); ?> Experience Icon" class="icon"/>
                        <div>
                            <h3><?php echo e($skill->skills); ?></h3>
                            <p><?php echo e($skill->level); ?></p>
                        </div>
                    </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
    <img src="<?php echo e(asset('/assets/images/arrow.png')); ?>" alt="Arrow Icon" class="icon arrow" onclick="location.href = './#projects'">
</section>
<section id="projects">
    <p class="section__text__p1">Browser My Recent</p>
    <h1 class="title">Projects</h1>
    <div class="experience-details-container">
        <div class="about-containers">
            <?php if(count($projects)>0): ?>
            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="details-container color-container">
                <?php
                    $projectImg = $project->project_pic !== null ? Voyager::image($project->project_pic) : asset('/assets/images/project-1.png'); 
                ?>
                <div class="article-container">
                    <img src="<?php echo e($projectImg); ?>" alt="<?php echo e($project->title); ?>" class="project-img"/>
                </div>
                <h2 class="experience-sub-title project-title"><?php echo e($project->title); ?></h2>
                <div class="btn-container">
                    <?php if($project->github): ?>
                    <button class="btn btn-color-2 project-btn" onclick="window.open('<?php echo e($project->github); ?>','_blank');">
                        Github
                    </button>
                    <?php endif; ?>
                    <?php if($project->live): ?>
                    <button class="btn btn-color-2 project-btn" onclick="window.open('<?php echo e($project->live); ?>','_blank');">
                        Live Demo
                    </button>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            
        </div>
    </div>
    <img src="<?php echo e(asset('/assets/images/arrow.png')); ?>" alt="Arrow Icon" class="icon arrow" onclick="location.href = './#contact'">
</section>
<section id="contact">
    <p class="section__text__p1">Get in Touch</p>
    <h1 class="title">Contact Me</h1>
    <div class="contact-info-upper-container">
        <?php if(setting('site.email')): ?>
        <div class="contact-info-container">
            <img src="<?php echo e(asset('/assets/images/email.png')); ?>" alt="Email Icon" class="icon contact-icon email-icon"/>
            <p><a href="mailto:<?php echo e(setting('site.email')); ?>"><?php echo e(setting('site.email')); ?></a></p>
        </div>
        <?php endif; ?>
        <?php if(setting('site.linkedin')): ?>
        <div class="contact-info-container">
            <img src="<?php echo e(asset('/assets/images/linkedin.png')); ?>" alt="LinkedIn Icon" class="icon contact-icon"/>
            <p><a href="<?php echo e(setting('site.linkedin')); ?>" target="_blank">LinkedIn</a></p>
        </div>
        <?php endif; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/anupshakyacom/portfolio/resources/views/home.blade.php ENDPATH**/ ?>